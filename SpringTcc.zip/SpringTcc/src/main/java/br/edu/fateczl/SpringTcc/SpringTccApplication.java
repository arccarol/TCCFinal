package br.edu.fateczl.SpringTcc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTccApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTccApplication.class, args);
	}

}
